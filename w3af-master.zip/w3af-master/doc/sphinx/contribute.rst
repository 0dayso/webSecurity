Contribute
==========

Contributions of **any type are always welcome**, over the past years we've received thousands
of emails with feedback, comments about new techniques to implement, new pieces of code,
usability improvements, translations of our documentation and many others.

Simply `send an email to the w3af develop mailing list <http://sourceforge.net/p/w3af/mailman/>`_
to let us know how you want to help, your interests, etc. and I'm sure something exciting will
come up.
